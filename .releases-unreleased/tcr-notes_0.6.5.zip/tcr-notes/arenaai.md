# arenaai.md — tcr-notes App

## Regole Fondamentali del Progetto

> **SE FUNZIONA NON SI TOCCA.**

- Ogni modifica al codice, alla struttura o alla logica deve essere documentata in questo file **prima** di essere applicata.
- Questo file è la storia del progetto: serve per poter ritornare sui passi senza problemi.
- Non rimuovere sezioni precedenti del changelog: aggiorna solo in coda.
- La versione corrente è indicata nel footer dell'app.

---

## Changelog

### [0.2.4.1-sync] — Sincronizzazione workspace con repository remoto
- **Data:** 2026-07-02
- **Modifiche:**
  - Sincronizzati tutti i file dal repository GitHub `PiBOH-EDU/tcr-notes` (branch main).
  - Aggiornati: `package.json`, `src/lib/supabase.js`, `src/main.jsx`, `src/components/Editor.jsx`, `src/components/Login.jsx`, `src/components/Dashboard.jsx`, `src/components/Footer.jsx`, `src/lib/storage.js`, `tailwind.config.js`, `README.md`, `CHANGELOG.md`, `arenaai.md`, `CODE OF CONDUCT.md`, `LICENSE`, `.gitignore`, `docs/SECURITY.md`, `docs/DISCLAIMER.md`.
  - Aggiunti nuovi file dal repo: `src/components/ErrorBoundary.jsx`.
  - Build di produzione eseguito con successo per verificare integrità post-sincronizzazione.

### [0.4.0-sync] — Sincronizzazione liste utenti dal repository remoto
- **Data:** 2026-07-03
- **Modifiche:**
  - Sincronizzato `src/data/authorized.js` dal repository GitHub `PiBOH-EDU/tcr-notes` (branch main).
  - Sincronizzato `src/data/banned.js` dal repository remoto.
  - Build di produzione eseguito per verificare integrità post-sincronizzazione.

### [0.6.0] — Highlight con simboli visibili, cursore preciso in Markdown, versionamento schematico
- **Autore:** PiBOH
- **Data:** 2026-07-03

#### Aggiunte
- `HighlightTextarea.jsx`: evidenziazione "GitHub-style" dove i delimitatori markdown (`**`, `~~`, `<!-- -->`) restano visibili ma attenuati (`opacity-60`), mentre il contenuto è formattato (grassetto, barrato, corsivo penombra).
- `Editor.jsx`: cliccando nella preview Markdown, il cursore viene posizionato nel punto testuale corrispondente della textarea (stima via `caretPositionFromPoint` / `caretRangeFromPoint` + TreeWalker sui text nodes). Ignora il click se su un link.

#### Modifiche
- Bump versione schematica a **0.6.0** (`package.json`, `Footer.jsx`, `InfoMenu.jsx`, `CHANGELOG.md`, `arenaai.md`).

### [0.5.0] — Highlight inline, no-save unchanged, badge Supabase, rimosso ❌ Align
- **Autore:** PiBOH
- **Data:** 2026-07-03

#### Aggiunte
- Componente `HighlightTextarea.jsx` con doppio layer: textarea trasparente (`caret-blue-500`) sopra e `<pre>` formattato sotto. Evidenzia in tempo reale:
  - `**testo**` → grassetto
  - `~~testo~~` → barrato (opacity 60)
  - `<!-- commento -->` → penombra (opacity 30, italic)
  - Non applicato a link, headings, liste, codice, immagini.
- **Badge promemoria Supabase**: banner rosso animato (`animate-pulse`) che appare se il progetto Supabase è in pausa o irraggiungibile. Check al mount e ogni 5 minuti via `setInterval`.

#### Modifiche
- `Editor.jsx`: `updateContent` e `triggerSave` ora controllano se `newContent === lastSavedContent.current` e skipano salvataggio/stato dirty se invariato.
- `MarkdownToolbar.jsx`: rimosso pulsante "❌ Align".
- `Dashboard.jsx`: aggiunto stato `supabaseStatus` e banner condizionale.
- Aggiornata versione ovunque a **0.5.0**.

### [0.4.9] — Avviso dati personali
- **Autore:** PiBOH
- **Data:** 2026-07-03

#### Aggiunte
- Banner avviso nella schermata di login: "⚠️ Attenzione: non inserire dati personali, numeri di telefono, indirizzi o informazioni sensibili negli appunti. Il contenuto è condiviso con tutta la classe."
- Nota nel footer con lo stesso avviso.
- Sezione in `docs/LIMITATIONS.md` sulla riservatezza dei contenuti.

#### Modifiche
- Aggiornata versione ovunque a **0.4.9**.

### [0.4.8] — Salvataggio manuale, menu info aggiornato
- **Autore:** PiBOH
- **Data:** 2026-07-03

#### Aggiunte
- Pulsante **💾 Salva** nella status bar dell'editor per salvataggio manuale immediato.
- Scorciatoia da tastiera `Ctrl+S` / `Cmd+S` per salvare manualmente.

#### Modifiche
- Menu Info: rimosso link a "GUIDA SUPABASE", aggiunto "(GitHub)" alla voce di feedback.
- Versione **0.4.8**.

### [0.4.7-sync2] — README snellito, rimosse ripetizioni
- **Data:** 2026-07-03
- **Modifiche:**
  - Riscritto `README.md` rimuovendo la sezione "Configurazione Supabase (passo-passo)" (già in `GUIDA-SUPABASE.md`), la sezione "Struttura del database" e il troubleshooting dettagliato (già nella guida).
  - Aggiunta tabella riassuntiva della documentazione.
  - Sezione "Gestione utenti" ridotta ai soli riferimenti ai file e al formato.
  - Versione nel README aggiornata a 0.4.7.

### [0.4.7-sync] — Sincronizzazione liste utenti dal repository remoto
- **Data:** 2026-07-03
- **Modifiche:**
  - Sincronizzato `src/data/authorized.js` dal repository GitHub `PiBOH-EDU/tcr-notes` (branch main).
  - Sincronizzato `src/data/banned.js` dal repository remoto.
  - Build di produzione eseguito per verificare integrità post-sincronizzazione.

### [0.4.7] — Fix stati salvataggio, click preview → testo piano, link markdown, limite 500KB
- **Autore:** PiBOH
- **Data:** 2026-07-03

#### Aggiunte
- Stato `saveState` in `Editor.jsx` con 3 stati: `saved` (✅), `dirty` (📝), `saving` (⏳). Ora quando l'utente scrive compare immediatamente "📝 Modificato", poi "⏳ Salvataggio..." durante il save, e infine "✅ Salvato".
- Componente `MarkdownLink` che intercetta i link in rendering e aggiunge `https://` se manca il protocollo, fixando il problema dei redirect relativi al dominio dell'app.
- Pulsante "⬅️ Sinistra" nella toolbar per allineamento a sinistra.
- Pulsante "❌ Align" che rimuove i tag `<div align="...">` dal testo selezionato.

#### Modifiche
- `handleMarkdownClick`: cliccando sulla preview Markdown si passa direttamente a **Testo piano** (`setIsMarkdownView(false)`), non più solo edit mode dentro la preview.
- Limite upload immagini ridotto a **500 KB**.
- Aggiornata versione ovunque a **0.4.7**.

### [0.4.6] — Etichette toggle, placeholder toolbar, link feedback
- **Autore:** PiBOH
- **Data:** 2026-07-03

#### Aggiunte
- Menu Info: sezione "Feedback" con link agli issue template.
- Toolbar markdown: placeholder descrittivi.

#### Modifiche
- Toggle editor: "Testo piano" / "Rendering Markdown".
- Versione **0.4.6**.

### [0.4.5] — Fix vulnerabilità Dependabot (vite, esbuild, launch-editor)
- **Autore:** PiBOH
- **Data:** 2026-07-03

#### Sicurezza
- Fix 4 alert Dependabot:
  - `vite` HIGH: `server.fs.deny` bypass on Windows alternate paths
  - `vite` MODERATE: Path Traversal in Optimized Deps `.map` Handling
  - `launch-editor` MODERATE: NTLMv2 hash disclosure via UNC path handling
  - `esbuild` MODERATE: enables any website to send any requests to the development server
- Aggiornato `vite` da 5.4.21 a 6.4.3 (versione patchata). `npm audit` riporta ora **0 vulnerabilità**.
- Nota: tutte le vulnerabilità riguardavano il **server di sviluppo locale**, non la build di produzione su Vercel.
- Aggiornata versione ovunque a **0.4.5**.

### [0.4.4] — Fix markdown editing, undo/redo, autosave 1min, limite 1MB
- **Autore:** PiBOH
- **Data:** 2026-07-03

#### Aggiunte
- Sistema Undo/Redo con stack custom (max 100 stati): pulsanti ↩ Annulla / ↪ Ripeti nella status bar.
- Scorciatoie da tastiera: `Ctrl+Z` (annulla), `Ctrl+Y` / `Ctrl+Shift+Z` (ripeti).
- Listener keydown globale: premendo un tasto in modalità anteprima Markdown si entra automaticamente in edit e il carattere viene inserito.
- `Escape` per tornare all'anteprima Markdown dall'editor.

#### Modifiche
- Fix modalità Markdown: rimosso `onBlur` automatico che chiudeva inaspettatamente l'editor. Ora l'utente controlla esplicitamente quando uscire (toggle o Escape).
- Autosave aumentato da 1 secondo a **60 secondi** (1 minuto).
- Limite upload immagini ridotto da 1.5 MB a **1 MB**.
- Aggiornata versione ovunque a **0.4.4**.

### [0.4.3] — Menu Info, limite immagini 1.5MB, mobile UI overhaul
- **Autore:** PiBOH
- **Data:** 2026-07-03

#### Aggiunte
- Componente `InfoMenu.jsx` con dropdown che mostra versione, autore, classe e link a tutta la documentazione (SECURITY, DISCLAIMER, LIMITATIONS, CODE OF CONDUCT, CHANGELOG, GUIDA SUPABASE, LICENSE).
- Controllo dimensione immagini in `MarkdownToolbar.jsx`: massimo 1.5 MB, alert con dimensione effettiva del file se superato.

#### Modifiche
- `Dashboard.jsx`: header rivisto — più compatto su mobile, badge utente nascosto su < sm, pulsanti Esporta/Importa nascosti su < lg, InfoMenu aggiunto.
- `Editor.jsx`: status bar responsive (flex-col su mobile, flex-row su sm), toggle markdown ridimensionato, testi più piccoli su mobile.
- `MarkdownToolbar.jsx`: separatori verticali nascosti su mobile (`hidden sm:inline`), bottoni con `whitespace-nowrap`.
- Altezze editor/preview adattive: `min-h-[50vh]` su mobile vs `calc(100vh-340px)` su desktop.
- Aggiornata versione ovunque a **0.4.3**.

### [0.4.2] — Documentazione limitazioni servizi esterni
- **Autore:** PiBOH
- **Data:** 2026-07-03

#### Aggiunte
- Creato `docs/LIMITATIONS.md` con tabella completa dei vincoli di Supabase Free Tier (500MB, 2GB bandwidth, 200 connessioni, pausa dopo 7gg, ecc.), Vercel Hobby (cold start, no SLA, ecc.), browser (localStorage 5-10MB, immagini base64), sicurezza (no E2E, no audit log, RLS aperte).
- Aggiunte raccomandazioni pratiche per gli utenti (export regolare, non caricare immagini grandi, monitorare spazio).
- Link a `LIMITATIONS.md` inseriti in `README.md` (sezione Documentazione), `GUIDA-SUPABASE.md` (prima dei prerequisiti), `docs/DISCLAIMER.md` (sezione servizi terze parti), `docs/SECURITY.md` (sezione limitazioni).
- Aggiornata versione ovunque a **0.4.2**.

### [0.4.1] — Rinomina titoli e capitoli
- **Autore:** PiBOH
- **Data:** 2026-07-03

#### Aggiunte
- Funzioni `renameTitle(id, newName)` e `renameChapter(id, newName)` in `src/lib/storage.js` per aggiornare i nomi su Supabase.
- UI di rinomina inline nella sidebar: pulsante ✏️ accanto a ogni titolo e capitolo.
- Input editabile con salvataggio su Enter/✓ e annullamento su Escape/✕.
- Stati `editingTitleId`, `editingChapterId`, `editTitleValue`, `editChapterValue` in `Dashboard.jsx`.
- Aggiornata versione ovunque a **0.4.1**.

### [0.4.0] — Toolbar markdown, responsive mobile, upload immagini, issue templates
- **Autore:** PiBOH
- **Data:** 2026-07-03

#### Aggiunte
- Componente `MarkdownToolbar` con pulsanti per formattazione: grassetto, corsivo, barrato, H1/H2/H3, elenchi puntati/numerati, citazioni, blocchi codice inline e multilinea, link, upload immagini (base64 inline), allineamento centro/destra.
- Supporto HTML in markdown tramite dipendenza `rehype-raw` per allineamento testo e formattazioni avanzate.
- Upload immagini: input file nascosto che converte in data URL base64 e inserisce sintassi markdown `![nome](data:image/...)"`.
- Dashboard completamente responsive: sidebar diventa drawer overlay su mobile attivabile da hamburger menu; header compatto con icone; overlay chiude sidebar al tap fuori.
- Indicatori utenti online: contatore con pallino verde pulsante in header; lista dropdown al click.
- Issue template GitHub in `.github/ISSUE_TEMPLATE/`: `bug_report.yml`, `feature_request.yml`, `config.yml` in stile XTetris.
- Persistenza checkbox documenti in `localStorage` (`tcr-docs-accepted`): dopo la prima accettazione il checkbox rimane pre-flaggato.

#### Modifiche
- `Editor.jsx`: integrata toolbar, aggiunto `rehype-raw`, migliorata preview markdown con classi `prose`.
- `Dashboard.jsx`: layout responsive con classi Tailwind `md:` e stati `sidebarOpen`/`showOnlineList`.
- `Login.jsx`: checkbox usa `localStorage` per persistenza.
- `package.json`: aggiunta dipendenza `rehype-raw`, versione bump a **0.4.0**.

### [0.2.4.1] — Fix schermata bianca da .env + nome reale residuo
- **Autore:** PiBOH
- **Data:** 2026-07-02

#### Corretto
- Schermata bianca al posto del login dopo aver configurato `.env`: `src/lib/supabase.js` eseguiva `createClient()` in modo eager al caricamento del modulo (import statico da `Dashboard.jsx`/`Editor.jsx`, caricati comunque da `App.jsx` anche prima del login). Un `.env` mancante o malformato faceva crashare tutta l'app React, lasciando visibile solo lo sfondo statico di `index.html`. Aggiunta validazione esplicita con messaggio d'errore chiaro.
- Aggiunto `ErrorBoundary` attorno ad `<App />` per evitare pagine bianche su qualsiasi errore di rendering futuro.
- Placeholder in `Login.jsx` per nomi multipli usava per errore `"DenisAndreiFlorin"`, coincidente con un utente reale in `authorized.js`. Sostituito con nome fittizio.
- **Causa radice del problema riportato:** Vite legge il `.env` solo all'avvio del server — va riavviato (`npm run dev`) dopo ogni modifica al file; pulire cache/cronologia browser non ha effetto.
- Aggiornata versione ovunque a **0.2.4.1**.

### [0.2.4] — Checkbox docs, nomi fittizi, SECURITY & DISCLAIMER
- **Autore:** PiBOH
- **Data:** 2026-07-02

#### Aggiunte
- Campo checkbox obbligatorio in login per confermare lettura di `SECURITY.md` e `DISCLAIMER.md`.
- File `docs/SECURITY.md` con policy di sicurezza e segnalazione vulnerabilità.
- File `docs/DISCLAIMER.md` con avvertenza legale completa ed esclusione di responsabilità.
- File `CHANGELOG.md` strutturato secondo le norme di Keep a Changelog.

#### Modifiche
- Login: campo Nome/i sopra, Cognome sotto, con spiegazione per nomi multipli.
- Messaggio errore autorizzati: aggiunto "Controlla di aver inserito correttamente i dati utente."
- Sostituiti nomi reali con nomi fittizi standard in tutti gli esempi (rossi.mario, bianchi.lucia, verdi.antonio, ecc.).
- Aggiornata versione ovunque a **0.2.4**.

### [0.0.2.3] — README + GUIDA-SUPABASE.md + nomi predefiniti + fix crash
- **Autore:** PiBOH
- **Data:** 2026-07-02

#### Aggiunte
- Creato `README.md` con panoramica progetto, requisiti, avvio e deploy.
- Creato `GUIDA-SUPABASE.md` dettagliato con guida passo-passo alla configurazione del server Supabase.
- Aggiunti nomi predefiniti in `authorized.js`.
- Aggiornati commenti in `authorized.js` e `banned.js`.
- Aggiornata versione ovunque a **0.0.2.3**.

### [0.6.1-sync] — Sincronizzazione completa con repository remoto + imgBB integration
- **Data:** 2026-07-04
- **Modifiche:**
  - Sincronizzati tutti i file dal repository GitHub `PiBOH-EDU/tcr-notes` (branch main), inclusi root e sottocartelle.
  - Integrato **imgBB** come servizio di hosting immagini al posto dell'upload base64 inline su Supabase.
  - Creato `src/lib/imgbb.js` con funzione `uploadImageToImgBB(base64Image, apiKey)`.
  - Modificato `MarkdownToolbar.jsx`: upload immagini ora invia a imgBB e inserisce URL pubblico in markdown `![nome](url)`.
  - Aggiornato `.env.example` con `VITE_IMGBB_API_KEY`.
  - Creato `docs/GUIDA-IMGBB.md` con guida passo-passo per principianti.
  - Spostato `GUIDA-SUPABASE.md` in `docs/GUIDA-SUPABASE.md`.
  - Build di produzione eseguito per verificare integrità post-modifica.

### [0.6.5] — Fix stile codice nel rendering Markdown
- **Autore:** PiBOH
- **Data:** 2026-07-04

#### Modifiche
- `Editor.jsx`: aggiunto componente custom `code` per ReactMarkdown che distingue codice inline (`<code>`) da blocchi di codice (`<pre><code>`).
  - Inline: sfondo semi-trasparente (`bg-gray-500/20`), bordi arrotondati, font monospace, padding.
  - Blocco: sfondo pieno (`bg-gray-900` dark / `bg-gray-100` light), bordi arrotondati, padding maggiore, scroll orizzontale.
- Aggiornata versione ovunque a **0.6.5**.
- Build di produzione eseguito per verificare integrità.

### [0.6.4] — Footer su una riga + Favicon browser
- **Autore:** PiBOH
- **Data:** 2026-07-04

#### Modifiche
- `Footer.jsx`: layout su **una sola riga** a 3 colonne:
  - Sinistra: "Materiale privato — accesso riservato alla classe 1FT (A.S. 2025/2026)"
  - Centro: "v0.6.4 · PiBOH"
  - Destra: "⚠️ Non inserire dati personali negli appunti"
  - Responsive: su schermi stretti i testi si riducono e vanno a capo se necessario.
- `index.html`: aggiunta favicon 📚 (libro) come SVG inline, visibile nella scheda del browser.
- Aggiornata versione ovunque a **0.6.4**.
- Build di produzione eseguito per verificare integrità.

### [0.6.3] — Fix password in MANUAL, state.json commentato, img 5MB, highlight codice, selezione testo preview, toggle immagini, fix menu online, footer compatto, uniforma font code/liste, fix liste numerate
- **Autore:** PiBOH
- **Data:** 2026-07-04

#### Sicurezza
- `docs/MANUAL.md`: rimossa password reale `Barsanti1FT`. Sostituita con placeholder `[password-fornita-dal-professore]`.

#### Aggiunte
- `public/state.json`: aggiunto campo `_readme` con spiegazione dei campi e degli stati disponibili.
- `HighlightTextarea.jsx`: evidenziazione per codice inline (`` `codice` ``) con sfondo semi-trasparente e bordi arrotondati, simile a GitHub.
- `Editor.jsx`: 
  - Possibilità di **selezionare il testo** nella preview Markdown senza switchare in edit mode (se c'è una selezione attiva, il click viene ignorato).
  - Toggle **"Mostra immagini"** nella status bar (default: attivo). Quando disattivato, le immagini nella preview vengono sostituite da un placeholder testuale `[Immagine nascosta]`.
- `Dashboard.jsx`: il menu utenti online ora si chiude cliccando fuori (come il menu Info).

#### Modifiche
- `MarkdownToolbar.jsx`: limite upload immagini aumentato da **500 KB a 5 MB**.
- `Footer.jsx`: altezza ridotta — padding diminuiti, testi più compatti.
- `Editor.jsx`: uniformata la dimensione del testo per blocchi di codice (`prose-pre:text-base`) e liste (`prose-li:text-base`, `prose-ol:text-base`) alla dimensione del testo normale.
- `Editor.jsx`: fix rendering liste numerate — aggiunte classi CSS esplicite `list-decimal` per garantire la numerazione corretta in sequenza.
- Aggiornata versione ovunque a **0.6.3**.
- Build di produzione eseguito per verificare integrità.

### [0.6.2] — Sistema di stato app visibile nel login
- **Autore:** PiBOH
- **Data:** 2026-07-04

#### Aggiunte
- `public/state.json`: file di configurazione per lo stato dell'app. Modificabile senza rebuild (servito staticamente).
  - `status`: `online` | `maintenance` | `testing` | `issue` | `offline`
  - `message`: testo personalizzato da mostrare nel banner
  - `banner`: booleano per forzare la visibilità
  - `bannerType`: `info` | `warning` | `error` per il colore del banner
- `Login.jsx`: fetch di `/state.json` al mount. Mostra banner colorato in base allo stato:
  - `online` → nessun banner (a meno che `banner: true`)
  - `maintenance` → banner giallo/arancione
  - `testing` → banner blu
  - `issue` → banner rosso
  - `offline` → banner rosso scuro + form di login disabilitato
- Aggiornata versione ovunque a **0.6.2**.
- Build di produzione eseguito per verificare integrità.

### [0.6.1] — Integrazione imgBB nei documenti + Manuale utente
- **Autore:** PiBOH
- **Data:** 2026-07-04

#### Aggiunte
- `docs/MANUAL.md`: manuale utente completo per principianti. Copre login, dashboard, editor (testo piano / rendering markdown), toolbar, salvataggio, undo/redo, export/import, cronologia, impostazioni, FAQ.
- `docs/SECURITY.md`: aggiunta sezione "API Key imgBB" — ricorda di non committare la chiave, trattarla come password, e nota che le immagini su imgBB sono pubbliche.
- `docs/DISCLAIMER.md`: aggiunto **imgBB** all'elenco dei servizi di terze parti.
- `docs/LIMITATIONS.md`: aggiunta sezione **5. imgBB (Hosting immagini)** con limiti del piano gratuito, privacy delle immagini pubbliche, durata, e raccomandazioni.

#### Modifiche
- Aggiornati i riferimenti alla versione nei documenti (dove presenti) a **0.6.1**.
- Build di produzione eseguito per verificare integrità.
- **Autore:** PiBOH
- **Data:** 2026-07-02

#### Aggiunte
- Ripristinata integrazione Supabase Realtime per sincronizzazione in tempo reale.
- Struttura database gerarchica: `titles` → `chapters` → `history`.
- Tabella `titles`: contiene gli argomenti principali (es. "test1").
- Tabella `chapters`: contiene i sotto-capitoli con `content`, `last_edited_by`, `updated_at`.
- Tabella `history`: cronologia automatica delle modifiche (max 50 versioni per capitolo).
- Realtime su `titles` e `chapters`: quando un utente crea/modifica/elimina, tutti gli altri vedono l'aggiornamento istantaneamente.
- Realtime broadcast "typing": mostra "✍️ [utente] sta scrivendo..." quando un compagno modifica il testo.
- Sincronizzazione contenuto in tempo reale: se un altro utente salva, il contenuto si aggiorna automaticamente nell'editor.
- Export/Import JSON per backup e ripristino completo del database.
- Fix controllo autorizzazioni: se `AUTHORIZED` è vuoto → password sufficiente; se ha elementi → solo whitelist può entrare; bannati bloccati sempre.
- Aggiornata versione ovunque a **0.0.2.2**.
